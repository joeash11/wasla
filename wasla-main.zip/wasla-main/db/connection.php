<?php
// ============================================
// Wasla Database Connection
// ============================================

$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';           // Default XAMPP has no password
$db_name = 'wasla_db';

// Create connection
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to utf8mb4
$conn->set_charset("utf8mb4");
?>
